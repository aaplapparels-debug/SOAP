"""
shoper_adapter.py

Adapter for extracting canonical business data (customers, items, sales,
sales orders) out of Shoper POS/ERP SQL Server databases.

Shoper stores each division as a *separate* physical database on the same
SQL Server instance (e.g. one database per division: SPM, SPW, Thermal,
KTH). This adapter loops over however many divisions a tenant's config
lists -- it makes no assumption that there are exactly four, so a future
tenant with a different division count needs zero code changes here.

Python concepts used below, since you're reading this while learning:

- `class` bundles related data + functions (called "methods" once they're
  inside a class) together. Think of a class as a blueprint. Writing
  `ShoperAdapter(divisions=[...])` creates one *instance* of that
  blueprint -- one adapter, configured for one tenant's specific list of
  division databases.
- `self` is how a method refers back to its own instance's data. It's
  always the first parameter of a method, and Python passes it in
  automatically -- you never type it yourself when *calling* a method,
  only when *defining* one.
- `@dataclass` is a shortcut for classes that are mostly just a bunch of
  fields with no real logic. It auto-writes the boring "store these
  values on self" code for you.
- Type hints like `-> pd.DataFrame` are notes for humans (and your
  editor) about what a function returns. Python doesn't enforce them at
  runtime -- they're documentation, not a contract -- but they make code
  much easier to read and catch mistakes early.
- A leading underscore, like `_connect`, is a Python convention meaning
  "internal helper, not meant to be called from outside this class."
  Nothing stops you from calling it anyway -- it's a signal, not a lock.
"""

import pyodbc
import pandas as pd
from dataclasses import dataclass
from typing import List


@dataclass
class DivisionConfig:
    """One division = one physical Shoper database to connect to."""
    division_name: str   # e.g. "SPM", "SPW", "Thermal", "KTH"
    server: str           # e.g. "localhost\\STAGING_SERVER" -- the native instance, no Docker involved
    database: str         # e.g. "Shoper962X" -- the restored database name
    username: str
    password: str


class ShoperAdapter:
    """Extracts canonical DataFrames from one or more Shoper division databases."""

    def __init__(self, divisions: List[DivisionConfig], backfill_years: int = 2):
        # Stored on `self` so every method below can see the division list
        # without it being passed in again and again to each method.
        self.divisions = divisions
        # How far back transactional extractions (sales, orders,
        # purchases) look. Customers and items aren't filtered by this
        # -- they're current master data, not history, so we always want
        # all of it regardless of when a customer/item was created.
        self.backfill_years = backfill_years

    def _connect(self, division: DivisionConfig) -> pyodbc.Connection:
        """Open a connection to one division's database."""
        conn_str = (
            "DRIVER={ODBC Driver 18 for SQL Server};"
            f"SERVER={division.server};"
            f"DATABASE={division.database};"
            f"UID={division.username};PWD={division.password};"
            "TrustServerCertificate=yes;"
        )
        return pyodbc.connect(conn_str)

    def _run_for_all_divisions(self, query: str) -> pd.DataFrame:
        """
        Runs the same query against every division's database, tags each
        result with the division name, and stacks them into one DataFrame.

        This loop is the whole trick: add a 5th division to the config
        list passed into __init__, and this same code handles it with no
        changes -- only the config gets longer.
        """
        frames = []
        for division in self.divisions:
            conn = self._connect(division)
            df = pd.read_sql(query, conn)
            df["division"] = division.division_name
            frames.append(df)
            conn.close()
        # pd.concat glues a list of DataFrames into one, stacked on top of
        # each other. ignore_index=True renumbers rows 0,1,2... instead of
        # keeping each division's own row numbers, which would collide.
        return pd.concat(frames, ignore_index=True)

    def extract_customers(self) -> pd.DataFrame:
        query = """
            SELECT Code AS customer_code, Nm AS customer_name,
                   CreditDays AS credit_days, CreditLimit AS credit_limit,
                   CreditUsed AS credit_used
            FROM Customers
        """
        return self._run_for_all_divisions(query)

    def extract_items(self) -> pd.DataFrame:
        query = """
            SELECT im.StockNo AS item_code, im.ItemDesc AS item_desc,
                   im.Class1Cd AS category_1, im.Class2Cd AS category_2,
                   im.SizeCd AS size, im.Retail_Price AS mrp,
                   im.CurrentCost AS current_cost,
                   sm.CurBalQty AS stock_qty, sm.CurBalVal AS stock_value
            FROM ItemMaster im
            LEFT JOIN StockMaster sm ON im.StockNo = sm.StockNo
        """
        return self._run_for_all_divisions(query)

    def extract_sales(self) -> pd.DataFrame:
        # SaleTrnType 2100 = Sales Invoice (counts positive)
        # SaleTrnType 1300 = Sales Return (subtracts)
        # SaleTrnType 1600 = Void/Cancel -- deliberately excluded entirely
        # (not included, not zeroed) since a void means the sale never
        # should have counted in the first place.
        #
        # Filtered to self.backfill_years -- this is the piece that
        # keeps this table from silently pulling in every year of
        # Shoper's history and blowing past Neon's free-tier storage cap.
        query = f"""
            SELECT h.DocDt AS sale_date, h.CustCd AS customer_code,
                   d.StockNo AS item_code, h.SaleTrnType AS trn_type,
                   CASE h.SaleTrnType WHEN 2100 THEN 1 WHEN 1300 THEN -1 END AS sign_multiplier,
                   d.DocQty AS qty, d.StkUpdtRate AS rate,
                   d.DocEntNetValue AS net_value,
                   h.DocNoPrefix AS doc_prefix, h.DocNo AS doc_no
            FROM SaleTrnHdr h
            JOIN StkTrnDtls d
                ON h.StkTrnTypeSale = d.TrnType
               AND h.StkTrnCtrlNoSale = d.TrnCtrlNo
            WHERE h.SaleTrnType IN (1300, 2100)
              AND h.DocDt >= DATEADD(YEAR, -{self.backfill_years}, GETDATE())
        """
        return self._run_for_all_divisions(query)

    def extract_sales_orders(self) -> pd.DataFrame:
        # PendingQty already comes pre-computed from Shoper -- no need to
        # derive it ourselves by comparing orders against invoices.
        # Same backfill_years filter as sales, applied to OrderDate.
        query = f"""
            SELECT OrderNo AS order_id, CustCd AS customer_code,
                   Stockno AS item_code, SalesStaff AS salesperson,
                   OrderDate AS order_date, BilledDate AS billed_date,
                   Orderqty AS order_qty, BilledQty AS billed_qty,
                   PendingQty AS pending_qty, CanceledQty AS cancelled_qty,
                   ReturnQty AS return_qty, MRP AS mrp,
                   InvValue AS invoice_value
            FROM CustSFASalesOrderDtls
            WHERE OrderDate >= DATEADD(YEAR, -{self.backfill_years}, GETDATE())
        """
        return self._run_for_all_divisions(query)

    def extract_purchases(self) -> pd.DataFrame:
        # TrnType 1100 = Purchase (confirmed via GenLookUp, same as the
        # sales type codes). Unlike sales, StkTrnHdr IS the purchase
        # header directly -- no separate bridging table, so the join to
        # StkTrnDtls uses (TrnType, TrnCtrlNo) with no indirection.
        #
        # PartyStkDocNo / PartyStkDocDt are the VENDOR's own invoice
        # number and date -- distinct from DocNoPrefix/DocNo, which is
        # Shoper's own internal document numbering, not the vendor's.
        # Same backfill_years filter as sales, applied to DocDt.
        query = f"""
            SELECT h.PartyStkDocNo AS vendor_invoice_no,
                   h.PartyStkDocDt AS vendor_invoice_date,
                   h.DocNoPrefix AS doc_prefix, h.DocNo AS doc_no,
                   h.DocDt AS entry_date, h.PartyId AS vendor_code,
                   d.StockNo AS item_code, d.DocQty AS qty,
                   d.StkUpdtRate AS rate, d.DocEntNetValue AS net_value
            FROM StkTrnHdr h
            JOIN StkTrnDtls d
                ON h.TrnType = d.TrnType
               AND h.TrnCtrlNo = d.TrnCtrlNo
            WHERE h.TrnType = 1100
              AND h.DocDt >= DATEADD(YEAR, -{self.backfill_years}, GETDATE())
        """
        return self._run_for_all_divisions(query)


# ------------------------------------------------------------------
# Example usage -- this is how you'd actually call this from a script.
# The `if __name__ == "__main__":` guard means this block only runs when
# you execute this file directly (python shoper_adapter.py), not when
# some other file imports ShoperAdapter from this one.
# ------------------------------------------------------------------
if __name__ == "__main__":
    # Same config file restore_shoper_backups.py uses -- one source of
    # truth for divisions, host, and credentials. No hardcoded values
    # here anymore, so dev vs. prod is just which config file is active.
    from config_loader import load_config

    config = load_config()
    sql_cfg = config["sql_server"]

    aapl_divisions = [
        DivisionConfig(
            division_name=division["name"],
            server=sql_cfg["host"],
            database=division["staging_db"],  # e.g. ShoperStaging_SPM -- the restored DB, not the original Shoper DB name
            username=sql_cfg["sa_username"],
            password=sql_cfg["sa_password"],
        )
        for division in config["divisions"]
    ]

    adapter = ShoperAdapter(aapl_divisions, backfill_years=config["sync"]["initial_backfill_years"])

    print("=== Customers ===")
    customers_df = adapter.extract_customers()
    print(customers_df.head())
    print(f"Total rows: {len(customers_df)}\n")

    print("=== Items ===")
    items_df = adapter.extract_items()
    print(items_df.head())
    print(f"Total rows: {len(items_df)}\n")

    print("=== Sales ===")
    sales_df = adapter.extract_sales()
    print(sales_df.head())
    print(f"Total rows: {len(sales_df)}\n")

    print("=== Sales Orders ===")
    orders_df = adapter.extract_sales_orders()
    print(orders_df.head())
    print(f"Total rows: {len(orders_df)}\n")

    print("=== Purchases ===")
    purchases_df = adapter.extract_purchases()
    print(purchases_df.head())
    print(f"Total rows: {len(purchases_df)}")
