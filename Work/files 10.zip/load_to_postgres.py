"""
load_to_postgres.py

Runs ShoperAdapter's extractions and loads them into the canonical
Postgres (Neon) tables defined in canonical_schema.sql.

- customers, items: always a full refresh (TRUNCATE + reload). Small
  master data, changes slowly, no real cost to just redoing it fully
  every run.
- sales, purchases: incremental via a watermark. sync_state remembers
  the last successful sync time per table; each run only pulls rows
  newer than that, then APPENDS them (never re-touches old rows). Safe
  because both are treated as immutable once posted -- a correction in
  Shoper shows up as a new row (e.g. a sales return), not an edit to
  an old one.
- sales_orders: also always a full refresh, same as customers/items --
  but for a different reason. This table is a live snapshot of
  "genuinely actionable pending orders" (see extract_sales_orders):
  currently pending AND placed within the recent lookback window, not
  history. An upsert-based approach was tried and rejected: it can only
  add or update rows, never remove one that's no longer true (e.g. an
  order that got fully billed, or aged out of the window since the
  last run), which would leave stale, wrong pending_qty values sitting
  around forever with no way to detect they'd gone stale. TRUNCATE +
  reload avoids that entirely -- every run reflects exactly what's
  actionable right now, nothing more.

New Python/SQL concepts in this file:
- `with engine.begin() as conn:` opens a transaction that automatically
  commits if the block succeeds, or rolls back if anything inside it
  raises an exception -- safer than manually calling commit/rollback.
"""

import datetime

import psycopg2
import pandas as pd
from sqlalchemy import create_engine, text

from config_loader import load_config
from shoper_adapter import ShoperAdapter, DivisionConfig


def get_engine(connection_string: str):
    return create_engine(connection_string)


def apply_schema(engine, schema_file: str = "canonical_schema.sql"):
    """Runs canonical_schema.sql against the database -- safe to run
    every time, since every CREATE TABLE in that file uses
    IF NOT EXISTS, so it does nothing if the tables already exist."""
    with open(schema_file, "r") as f:
        schema_sql = f.read()
    with engine.begin() as conn:
        for statement in schema_sql.split(";"):
            statement = statement.strip()
            if statement:
                conn.execute(text(statement))


def get_last_synced(engine, source_table: str):
    """Returns the last_synced_at timestamp for this table, or None if
    it's never been synced before -- None is the signal to do a full
    backfill instead of an incremental pull."""
    with engine.begin() as conn:
        result = conn.execute(
            text("SELECT last_synced_at FROM sync_state WHERE source_table = :t"),
            {"t": source_table},
        ).fetchone()
    return result[0] if result else None


def set_last_synced(engine, source_table: str, when: datetime.datetime):
    with engine.begin() as conn:
        conn.execute(
            text("""
                INSERT INTO sync_state (source_table, last_synced_at)
                VALUES (:t, :w)
                ON CONFLICT (source_table) DO UPDATE SET last_synced_at = :w
            """),
            {"t": source_table, "w": when},
        )


def full_reload_table(engine, df: pd.DataFrame, table_name: str):
    """TRUNCATE + reload -- used for customers/items, and for the very
    first sync of any table, all inside one transaction."""
    with engine.begin() as conn:
        conn.execute(text(f"TRUNCATE TABLE {table_name}"))
        df.to_sql(table_name, conn, if_exists="append", index=False)
    print(f"Full reload: {len(df)} rows into {table_name}")


def append_new_rows(engine, df: pd.DataFrame, table_name: str):
    """Adds rows without touching what's already there -- correct for
    sales/purchases, which are immutable once posted."""
    if df.empty:
        print(f"No new rows for {table_name}")
        return
    with engine.begin() as conn:
        df.to_sql(table_name, conn, if_exists="append", index=False)
    print(f"Appended {len(df)} new rows into {table_name}")


def sync_append_only_table(engine, adapter_method, table_name: str):
    """
    Shared logic for sales and purchases -- both immutable-once-posted,
    both use the same "watermark, then append" pattern. Passing the
    adapter's extraction method itself (adapter.extract_sales, e.g.)
    as an argument means this one function works for both instead of
    writing the same branching logic twice.
    """
    last_synced = get_last_synced(engine, table_name)
    if last_synced is None:
        print(f"No previous sync for {table_name} -- running full backfill.")
        df = adapter_method()
        full_reload_table(engine, df, table_name)
    else:
        since = last_synced.date()
        print(f"Incremental sync for {table_name} since {since}...")
        df = adapter_method(since_date=since)
        append_new_rows(engine, df, table_name)
    set_last_synced(engine, table_name, datetime.datetime.now())


def run_load():
    config = load_config()
    sql_cfg = config["sql_server"]
    pg_connection_string = config["postgres"]["connection_string"]

    divisions = [
        DivisionConfig(
            division_name=division["name"],
            server=sql_cfg["host"],
            database=division["staging_db"],
            username=sql_cfg["sa_username"],
            password=sql_cfg["sa_password"],
        )
        for division in config["divisions"]
    ]
    adapter = ShoperAdapter(
        divisions,
        financial_years_back=config["sync"]["financial_years_back"],
        sales_orders_lookback_days=config["sync"]["sales_orders_lookback_days"],
    )
    engine = get_engine(pg_connection_string)

    print("Applying schema (safe to run every time)...")
    apply_schema(engine)

    print("\n--- Customers (always full refresh) ---")
    full_reload_table(engine, adapter.extract_customers(), "customers")

    print("\n--- Items (always full refresh) ---")
    full_reload_table(engine, adapter.extract_items(), "items")

    print("\n--- Sales (incremental) ---")
    sync_append_only_table(engine, adapter.extract_sales, "sales")

    print("\n--- Purchases (incremental) ---")
    sync_append_only_table(engine, adapter.extract_purchases, "purchases")

    print("\n--- Sales Orders (full refresh, currently-pending snapshot) ---")
    full_reload_table(engine, adapter.extract_sales_orders(), "sales_orders")

    print("\nDone.")


if __name__ == "__main__":
    run_load()
