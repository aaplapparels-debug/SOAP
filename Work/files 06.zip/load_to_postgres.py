"""
load_to_postgres.py

Runs every ShoperAdapter extraction and loads the results into the
canonical Postgres (Neon) tables defined in canonical_schema.sql.

This is a full-refresh load: each table is TRUNCATEd and completely
reloaded every run. Simple and correct for a first pass -- the
incremental sync logic (watermark for sales, "still open" recheck for
orders) is a deliberately separate, later step, not tangled into this
one.

New Python concepts in this file:
- `sqlalchemy.create_engine(connection_string)` builds a reusable
  connection manager for Postgres -- pandas' `to_sql` specifically
  wants a SQLAlchemy engine, not a raw psycopg2 connection (that's what
  the UserWarning about "pandas only supports SQLAlchemy connectable"
  was pointing at, back when we saw it with pyodbc/SQL Server).
- `df.to_sql(table_name, engine, if_exists="append", index=False)`
  writes a whole DataFrame into a table in one call -- pandas builds
  the INSERT statements for you. `index=False` means don't write
  pandas' own row-number index as a column; we don't want that in the
  database.
- `with engine.begin() as conn:` opens a transaction that automatically
  commits if the block succeeds, or rolls back if anything inside it
  raises an exception -- safer than manually calling commit/rollback.
"""

import psycopg2
import pandas as pd
from sqlalchemy import create_engine, text

from config_loader import load_config
from shoper_adapter import ShoperAdapter, DivisionConfig


def get_engine(connection_string: str):
    return create_engine(connection_string)


def apply_schema(engine, schema_file: str = "canonical_schema.sql"):
    """Runs canonical_schema.sql against the database -- safe to run
    every time, since every CREATE TABLE in that file uses
    IF NOT EXISTS, so it does nothing if the tables already exist."""
    with open(schema_file, "r") as f:
        schema_sql = f.read()
    with engine.begin() as conn:
        # Postgres wants one statement per execute() call -- split on
        # semicolons and run each CREATE TABLE separately.
        for statement in schema_sql.split(";"):
            statement = statement.strip()
            if statement:
                conn.execute(text(statement))


def load_table(engine, df: pd.DataFrame, table_name: str):
    """Truncates the table, then loads the fresh DataFrame into it --
    all inside one transaction, so a failure partway through leaves the
    old data intact rather than a half-truncated, half-loaded table."""
    with engine.begin() as conn:
        conn.execute(text(f"TRUNCATE TABLE {table_name}"))
        df.to_sql(table_name, conn, if_exists="append", index=False)
    print(f"Loaded {len(df)} rows into {table_name}")


def run_load():
    config = load_config()
    sql_cfg = config["sql_server"]
    pg_connection_string = config["postgres"]["connection_string"]

    divisions = [
        DivisionConfig(
            division_name=division["name"],
            server=sql_cfg["host"],
            database=division["staging_db"],
            username=sql_cfg["sa_username"],
            password=sql_cfg["sa_password"],
        )
        for division in config["divisions"]
    ]
    adapter = ShoperAdapter(divisions, backfill_years=config["sync"]["initial_backfill_years"])
    engine = get_engine(pg_connection_string)

    print("Applying schema (safe to run every time)...")
    apply_schema(engine)

    print("\nExtracting and loading customers...")
    load_table(engine, adapter.extract_customers(), "customers")

    print("\nExtracting and loading items...")
    load_table(engine, adapter.extract_items(), "items")

    print("\nExtracting and loading sales...")
    load_table(engine, adapter.extract_sales(), "sales")

    print("\nExtracting and loading sales orders...")
    load_table(engine, adapter.extract_sales_orders(), "sales_orders")

    print("\nExtracting and loading purchases...")
    load_table(engine, adapter.extract_purchases(), "purchases")

    print("\nDone.")


if __name__ == "__main__":
    run_load()
