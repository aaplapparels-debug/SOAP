-- canonical_schema.sql
--
-- The canonical schema: one table per ShoperAdapter extraction method.
-- No tenant_id column anywhere -- isolation happens at the database
-- level (each tenant gets their own Neon project), so these tables
-- stay clean, matching the decision made early in this project.
--
-- This is a full-refresh design for now: each load run TRUNCATEs and
-- reloads these tables completely, rather than incrementally updating
-- them. That's deliberately simple for this first pass -- the
-- watermark/incremental sync logic is a separate, later step.

CREATE TABLE IF NOT EXISTS customers (
    customer_code   VARCHAR(50),
    customer_name   VARCHAR(255),
    credit_days     INTEGER,
    credit_limit    NUMERIC(14, 2),
    credit_used     NUMERIC(14, 2),
    division        VARCHAR(20),
    PRIMARY KEY (customer_code, division)
);

CREATE TABLE IF NOT EXISTS items (
    item_code       VARCHAR(50),
    item_desc       VARCHAR(255),
    category_1      VARCHAR(50),
    category_2      VARCHAR(50),
    size            VARCHAR(20),
    mrp             NUMERIC(12, 2),
    current_cost    NUMERIC(12, 2),
    stock_qty       NUMERIC(12, 2),
    stock_value     NUMERIC(14, 2),
    division        VARCHAR(20),
    PRIMARY KEY (item_code, division)
);

CREATE TABLE IF NOT EXISTS sales (
    sale_date       DATE,
    customer_code   VARCHAR(50),
    item_code       VARCHAR(50),
    trn_type        INTEGER,
    sign_multiplier INTEGER,
    qty             NUMERIC(12, 2),
    rate            NUMERIC(12, 4),
    net_value       NUMERIC(14, 2),
    doc_prefix      VARCHAR(20),
    doc_no          INTEGER,
    division        VARCHAR(20)
    -- No primary key here -- a single invoice can have many identical-
    -- looking line items (same item, same rate) that are genuinely
    -- separate rows, so there's no natural unique combination of
    -- columns to build one from without an artificial row id.
);

CREATE TABLE IF NOT EXISTS sales_orders (
    order_id        VARCHAR(50),
    customer_code   VARCHAR(50),
    item_code       VARCHAR(50),
    salesperson     VARCHAR(100),
    order_date      DATE,
    billed_date     DATE,
    order_qty       NUMERIC(12, 2),
    billed_qty      NUMERIC(12, 2),
    pending_qty     NUMERIC(12, 2),
    cancelled_qty   NUMERIC(12, 2),
    return_qty      NUMERIC(12, 2),
    mrp             NUMERIC(12, 2),
    invoice_value   NUMERIC(14, 2),
    division        VARCHAR(20),
    -- One order can have several line items (one per item ordered),
    -- so the natural unique key is the combination of order, item, and
    -- division -- not order_id alone. This is what the incremental
    -- sync's UPSERT matches on to update an existing line's pending_qty
    -- instead of inserting a duplicate row for the same line.
    PRIMARY KEY (order_id, item_code, division)
);

CREATE TABLE IF NOT EXISTS purchases (
    vendor_invoice_no      VARCHAR(50),
    vendor_invoice_date    DATE,
    doc_prefix             VARCHAR(20),
    doc_no                 INTEGER,
    entry_date             DATE,
    vendor_code            VARCHAR(50),
    item_code              VARCHAR(50),
    qty                    NUMERIC(12, 2),
    rate                   NUMERIC(12, 4),
    net_value              NUMERIC(14, 2),
    division               VARCHAR(20)
);

-- Tracks the last successful load per table -- not used yet, but
-- created now so the incremental sync step (next up after this) has
-- somewhere to record its watermark without needing a schema change.
CREATE TABLE IF NOT EXISTS sync_state (
    source_table    TEXT PRIMARY KEY,
    last_synced_at  TIMESTAMP
);
