"""
restore_shoper_backups.py

Nightly orchestration: for each division in config.<env>.yaml, find
tonight's backup zip, extract it, restore it into that division's
staging database, then clean up the extracted files. Never touches or
deletes the original zip in watch_folder -- only ever reads it.

Run this before shoper_adapter.py each night -- it's what makes sure
"tonight's data" actually exists in the ShoperStaging_* databases
before extraction tries to read from them.

PREREQUISITE (one-time): the container needs a bind mount, not the
named volume from our manual testing, so this script (on the host) can
put files somewhere SQL Server (inside the container) can see them:

    docker stop shoper-staging
    docker rm shoper-staging
    docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=YourPasswordHere" -p 14330:1433 --name shoper-staging -v E:\\ShoperTemp:/var/opt/mssql/backup -d mcr.microsoft.com/mssql/server:2022-latest

The host path (E:\\ShoperTemp) must match `backup.temp_extract_folder`
in your config file exactly.

New Python concepts in this file:
- `glob.glob(pattern)` searches for files matching a wildcard pattern,
  the same way typing "A_62X_*.ZIP" into Windows Explorer's search box
  would -- `*` means "anything."
- `try / except` catches errors instead of letting them crash the whole
  program. Here, one division failing (e.g. tonight's zip missing)
  shouldn't stop the other three from restoring -- we catch the error,
  print it, and move on to the next division.
- `os.path.join(...)` builds file paths safely -- it's the correct way
  to combine folder + filename without worrying about missing slashes
  or Windows-vs-Linux differences.
"""

import glob
import os
import shutil
import zipfile

import pyodbc

from config_loader import load_config


CONTAINER_BACKUP_PATH = "/var/opt/mssql/backup"  # fixed -- matches the bind mount above


def find_latest_zip(watch_folder: str, pattern: str) -> str:
    """Finds the most recently modified file matching this division's
    pattern. Picking by modification time (not just 'first match') 
    handles an old file matching the same pattern still sitting around
    from a previous night."""
    matches = glob.glob(os.path.join(watch_folder, pattern))
    if not matches:
        raise FileNotFoundError(f"No backup zip found matching '{pattern}' in {watch_folder}")
    return max(matches, key=os.path.getmtime)


def extract_zip(zip_path: str, temp_folder: str, division_name: str) -> str:
    """Extracts into its own subfolder per division, so divisions never
    overwrite each other's files if this ever runs concurrently."""
    extract_to = os.path.join(temp_folder, division_name)
    os.makedirs(extract_to, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(extract_to)
    return extract_to


def find_main_backup_file(extract_folder: str) -> str:
    """The extracted folder holds the main Shoper backup plus a smaller
    system-database backup (tspsysdb9, from our earlier reconnaissance).
    Picking by file size is more robust than guessing a name pattern
    that might not hold for every division or every Shoper version."""
    files = [os.path.join(extract_folder, f) for f in os.listdir(extract_folder)
             if os.path.isfile(os.path.join(extract_folder, f))]
    if not files:
        raise FileNotFoundError(f"No files found after extracting into {extract_folder}")
    return max(files, key=os.path.getsize)


def restore_database(conn, backup_file_container_path: str, staging_db: str):
    """RESTORE FILELISTONLY first, to discover this specific backup's
    logical file names (they vary by database -- can't hardcode them),
    then builds and runs the real RESTORE DATABASE from that."""
    cursor = conn.cursor()

    cursor.execute(f"RESTORE FILELISTONLY FROM DISK = '{backup_file_container_path}'")
    file_list = cursor.fetchall()

    move_clauses = []
    for row in file_list:
        logical_name = row.LogicalName
        file_type = row.Type  # 'D' = data file, 'L' = log file
        extension = "mdf" if file_type == "D" else "ldf"
        target_path = f"/var/opt/mssql/data/{staging_db}_{logical_name}.{extension}"
        move_clauses.append(f"MOVE '{logical_name}' TO '{target_path}'")

    move_sql = ", ".join(move_clauses)
    restore_sql = (
        f"RESTORE DATABASE {staging_db} FROM DISK = '{backup_file_container_path}' "
        f"WITH {move_sql}, REPLACE"
    )
    cursor.execute(restore_sql)
    conn.commit()


def run_nightly_restore():
    config = load_config()
    watch_folder = config["backup"]["watch_folder"]
    temp_folder = config["backup"]["temp_extract_folder"]
    sql_cfg = config["sql_server"]

    conn_str = (
        "DRIVER={ODBC Driver 18 for SQL Server};"
        f"SERVER={sql_cfg['host']};"
        f"UID={sql_cfg['sa_username']};PWD={sql_cfg['sa_password']};"
        "TrustServerCertificate=yes;"
    )
    # autocommit=True because RESTORE DATABASE can't run inside an
    # explicit transaction -- SQL Server rejects it otherwise.
    conn = pyodbc.connect(conn_str, autocommit=True)

    for division in config["divisions"]:
        name = division["name"]
        print(f"--- {name} ---")
        try:
            zip_path = find_latest_zip(watch_folder, division["backup_file_pattern"])
            print(f"Found: {zip_path}")

            extract_folder = extract_zip(zip_path, temp_folder, name)
            backup_file = find_main_backup_file(extract_folder)
            print(f"Main backup file: {backup_file}")

            # Translate the host-side extracted path into the path SQL
            # Server sees *inside* the container, via the bind mount.
            relative_path = os.path.relpath(backup_file, temp_folder).replace("\\", "/")
            container_path = f"{CONTAINER_BACKUP_PATH}/{relative_path}"

            restore_database(conn, container_path, division["staging_db"])
            print(f"Restored into {division['staging_db']}")

            # Only clean up on success -- if anything above raised, this
            # division's extracted files stay put for inspection instead
            # of silently disappearing.
            shutil.rmtree(extract_folder)
            print("Cleaned up temp files.")

        except Exception as e:
            print(f"FAILED for division {name}: {e}")
            # Deliberately not re-raising -- one division's zip missing
            # shouldn't stop the other three from restoring. Once this
            # runs unattended overnight, this print should become a log
            # line or alert you'll actually see the next morning.

    conn.close()


if __name__ == "__main__":
    run_nightly_restore()
