"""
upload_backups_to_drive.py

Runs on the PRODUCTION machine (the one with live Shoper + Tally).
Watches the backup folder and uploads any new Day-End zip to a shared
Google Drive folder. Deliberately lightweight -- a file upload, not a
database operation -- so it's safe to run during business hours without
meaningfully competing with live POS activity.

Meant to be scheduled (Windows Task Scheduler) every 30-60 minutes
during business hours. It only uploads files it hasn't uploaded before,
so running it often and getting "nothing new" most of the time is by
design, not wasted work.

--------------------------------------------------------------------
SETUP -- do this once before running:

1. Create a fresh Google Cloud service account (NOT the exposed one
   from earlier in this project) with Drive API access, and download
   its JSON key as drive_service_account.json, next to this script.

2. pip install google-api-python-client google-auth

3. In your own Google Drive, create a folder for these backups.
   IMPORTANT GOTCHA: a service account's own Drive storage quota is
   effectively zero by default -- if you upload directly to "the
   service account's Drive," it will likely fail with a storage-quota
   error, confusingly, even though the account clearly has Drive
   access. The fix: create the folder in YOUR OWN Drive account, then
   share that folder with the service account's email address (found
   in the JSON key file's "client_email" field) with Editor access.
   Uploads then count against YOUR quota, not the service account's.

4. Open that folder in a browser, copy the ID from the URL
   (drive.google.com/drive/folders/<THIS PART>), and put it in
   config.dev.yaml under google_drive.shared_folder_id.
--------------------------------------------------------------------

New Python concepts in this file:
- Google's client library uses a "service" object (built once, reused
  for every API call) as the entry point to everything -- similar in
  spirit to how a pyodbc connection is the entry point for SQL calls.
- `MediaFileUpload` / `MediaIoBaseDownload` are Google's wrappers for
  streaming a file up or down in chunks, rather than loading a huge
  file entirely into memory at once.
"""

import glob
import os

from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2 import service_account

from config_loader import load_config

DRIVE_SCOPES = ["https://www.googleapis.com/auth/drive"]


def get_drive_service(service_account_file: str):
    creds = service_account.Credentials.from_service_account_file(
        service_account_file, scopes=DRIVE_SCOPES
    )
    return build("drive", "v3", credentials=creds)


def list_files_in_drive_folder(service, folder_id: str) -> set:
    """Returns the set of filenames already sitting in the Drive folder,
    so we can skip anything already uploaded. A `set` (not a list) is
    used here because checking "is this name already in here?" is much
    faster with a set, and we don't care about order."""
    results = service.files().list(
        q=f"'{folder_id}' in parents and trashed = false",
        fields="files(id, name)",
    ).execute()
    return {f["name"] for f in results.get("files", [])}


def upload_file(service, local_path: str, folder_id: str):
    filename = os.path.basename(local_path)
    file_metadata = {"name": filename, "parents": [folder_id]}
    media = MediaFileUpload(local_path, resumable=True)
    service.files().create(body=file_metadata, media_body=media, fields="id").execute()


def run_upload_check():
    config = load_config()
    drive_cfg = config["google_drive"]
    watch_folder = config["backup"]["watch_folder"]

    service = get_drive_service(drive_cfg["service_account_file"])
    already_uploaded = list_files_in_drive_folder(service, drive_cfg["shared_folder_id"])

    # Check every division's pattern, not just one -- all four divisions'
    # zips live in the same watch_folder.
    for division in config["divisions"]:
        pattern = os.path.join(watch_folder, division["backup_file_pattern"])
        for local_file in glob.glob(pattern):
            filename = os.path.basename(local_file)
            if filename in already_uploaded:
                continue  # already relayed, nothing to do
            print(f"Uploading {filename}...")
            upload_file(service, local_file, drive_cfg["shared_folder_id"])
            print(f"Done: {filename}")


if __name__ == "__main__":
    run_upload_check()
