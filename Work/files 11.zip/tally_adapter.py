"""
tally_adapter.py

Adapter for extracting canonical financial data (outstanding debtors,
PDCs, receipts/collections, credit notes) from Tally via its local
XML/HTTP API. Fundamentally different mechanism from ShoperAdapter,
which queries SQL Server directly -- Tally exposes a TDL (Tally
Definition Language) interface over HTTP: POST an XML request
describing what's wanted, Tally returns XML back.

STATUS: extract_outstanding reuses an XML request shape already proven
against this real Tally install (from earlier work in this project).
extract_pdc reuses proven DETECTION LOGIC (future voucher date, future
cheque date, Tally's own ISPOSTDATED flag) from that same earlier work,
but wrapped in a new query structure here -- worth verifying its output
carefully even though the underlying logic is trusted. extract_receipts
and extract_credit_notes are fully NEW -- built on Tally's well-
documented bill-wise allocation mechanism (BILLALLOCATIONS.LIST), not
yet run against real data at all. Treat all three (pdc, receipts,
credit_notes) with the same "verify before trusting" discipline used
throughout this project -- run them, look at real rows, before wiring
any of this into a report.

Deliberately NOT extracting sales from Tally -- Shoper already
provides that, and pulling it from both places would risk double
counting or, worse, two numbers disagreeing with no way to tell which
is right.

New Python concepts, since you're reading this while learning:
- Tally's API isn't SQL -- it's a request/response XML protocol. We
  build an XML string describing what to fetch, POST it, then parse
  whatever XML comes back. `requests` makes the HTTP call;
  `xml.etree.ElementTree` (as ET) parses the response.
- `BILLALLOCATIONS.LIST` is Tally's own mechanism for linking a
  payment/credit-note entry back to the specific invoice it settles --
  the same idea as a foreign key in a SQL database, just expressed
  inside Tally's XML rather than a join column.
"""

import datetime
import re
import xml.etree.ElementTree as ET

import pandas as pd
import requests
from bs4 import BeautifulSoup

from shoper_adapter import get_financial_year_cutoff  # reuse the same FY-boundary math, not a copy


def sanitize_xml(raw_bytes: bytes) -> str:
    """Tally's XML responses sometimes contain control characters and
    unbound namespace prefixes that a strict XML parser chokes on.
    Cleans both before parsing -- proven approach against this Tally
    install from earlier work in this project."""
    try:
        text = raw_bytes.decode('utf-8', errors='ignore')
    except Exception:
        text = raw_bytes.decode('latin-1', errors='ignore')
    text = re.sub(r'&#x?(?:[0-8]|1[0-1]|1[4-9]|2[0-9]|3[0-1]);?', '', text, flags=re.IGNORECASE)
    text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F]', '', text)
    text = re.sub(r'<(/)?([a-zA-Z0-9_]+):', r'<\1\2_', text)
    text = re.sub(r'(\s[a-zA-Z0-9_]+):([a-zA-Z0-9_.-]+=)', r'\1_\2', text)
    return text


def identify_division(vch_no: str, party_name: str = '', vch_type: str = '') -> str:
    """Same SCRS/SWCRS/THCRS/KTHCRS prefix convention already confirmed
    to hold across both Tally and Shoper's own document numbering."""
    text = f'{vch_no} {party_name} {vch_type}'.upper()
    prefix_mapping = [
        ('KTHCRS', 'KTH'), ('SWCRS', 'SPW'), ('SCRS', 'SPM'), ('THCRS', 'THM'),
        ('SPW', 'SPW'), ('SPM', 'SPM'), ('THM', 'THM'), ('KTH', 'KTH'),
    ]
    for prefix, div in prefix_mapping:
        if prefix in text:
            return div
    return 'SPM'


def format_tally_date(date_str) -> str:
    """Formats any input date string into Tally's YYYYMMDD format, so
    dates from different fields (which can arrive in different formats)
    can be compared as plain strings. Proven logic from earlier work in
    this project."""
    d_str = str(date_str).strip()
    if len(d_str) == 8 and d_str.isdigit():
        return d_str
    for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%Y/%m/%d', '%d-%b-%Y'):
        try:
            dt = datetime.datetime.strptime(d_str, fmt)
            return dt.strftime('%Y%m%d')
        except ValueError:
            continue
    return d_str


class TallyAdapter:
    """Extracts canonical DataFrames from Tally via its local XML API."""

    SOURCE_SYSTEM = "tally"  # stamped onto every row this adapter produces

    def __init__(self, tally_url: str, financial_years_back: int):
        self.tally_url = tally_url
        self.cutoff = get_financial_year_cutoff(datetime.date.today(), financial_years_back)
        self.today = datetime.date.today()

    def extract_outstanding(self) -> pd.DataFrame:
        """
        Live Bills Receivable -- a current snapshot, not date-windowed.
        Outstanding balances are as-of-today by nature; there's no
        'range' to ask Tally for here.
        """
        xml_payload = """<ENVELOPE>
            <HEADER>
                <VERSION>1</VERSION>
                <TALLYREQUEST>Export</TALLYREQUEST>
                <TYPE>Data</TYPE>
                <ID>Bills Receivable</ID>
            </HEADER>
            <BODY>
                <DESC>
                    <STATICVARIABLES>
                        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
                    </STATICVARIABLES>
                </DESC>
            </BODY>
        </ENVELOPE>"""

        res = requests.post(self.tally_url, data=xml_payload, headers={'Content-Type': 'text/xml'}, timeout=120)
        res.raise_for_status()
        soup = BeautifulSoup(res.text, 'html.parser')
        bill_fixed_elements = soup.find_all(lambda t: t.name and t.name.lower() == 'billfixed')

        rows = []
        for fixed_elem in bill_fixed_elements:
            party_elem = fixed_elem.find(lambda t: t.name and t.name.lower() == 'billparty')
            date_elem = fixed_elem.find(lambda t: t.name and t.name.lower() == 'billdate')
            ref_elem = fixed_elem.find(lambda t: t.name and t.name.lower() == 'billref')
            amt_elem = fixed_elem.find_next(lambda t: t.name and t.name.lower() == 'billcl')

            name_val = party_elem.get_text(strip=True) if party_elem else ""
            if not name_val or name_val.lower() in ['ledger name', 'party name', 'name']:
                continue
            date_val = date_elem.get_text(strip=True) if date_elem else ""
            ref_val = ref_elem.get_text(strip=True) if ref_elem else ""
            amt_val = amt_elem.get_text(strip=True) if amt_elem else ""

            if name_val and amt_val:
                cleaned_amt = amt_val.replace(',', '').replace('Dr', '').replace('Cr', '').strip()
                try:
                    num_amt = abs(float(cleaned_amt))
                    if num_amt > 0:
                        rows.append({
                            'customer_name': name_val,
                            'invoice_date': date_val,
                            'invoice_reference': ref_val,
                            'pending_amount': num_amt,
                            'division': identify_division(ref_val, name_val),
                            'source_system': self.SOURCE_SYSTEM,
                        })
                except ValueError:
                    pass
        return pd.DataFrame(rows)

    def _fetch_vouchers_in_range(self, from_date: datetime.date, to_date: datetime.date, include_postdated: bool = False) -> list:
        """Shared helper: fetches ALL vouchers in a date range with full
        ledger-entry detail (including bill allocations and, when
        include_postdated=True, instrument/cheque date fields needed
        for PDC detection). Filtering by voucher type and by
        postdated-ness happens client-side afterward, in each specific
        extract_* method -- same pattern already proven to work here.

        include_postdated maps to Tally's own SVINCLUDEPOSTDATED flag,
        which tells Tally to include vouchers dated in the future in
        its response at all -- without it, Tally's default behavior
        may exclude them entirely, not just fail to flag them."""
        formatted_from = from_date.strftime('%Y%m%d')
        formatted_to = to_date.strftime('%Y%m%d')
        postdated_line = '<SVINCLUDEPOSTDATED TYPE="Logical">Yes</SVINCLUDEPOSTDATED>' if include_postdated else ''
        fetch_fields = (
            "DATE, VOUCHERNUMBER, VOUCHERTYPENAME, PARTYLEDGERNAME, "
            "ISPOSTDATED, INSTRUMENTDATE, INSTRUMENTNUMBER, BANKALLOCATIONS.*, "
            "ALLLEDGERENTRIES.*, LEDGERENTRIES.*"
        )

        req_xml = f"""<ENVELOPE>
            <HEADER>
                <VERSION>1</VERSION>
                <TALLYREQUEST>Export</TALLYREQUEST>
                <TYPE>Collection</TYPE>
                <ID>VoucherColl</ID>
            </HEADER>
            <BODY>
                <DESC>
                    <STATICVARIABLES>
                        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
                        <SVFROMDATE TYPE="Date">{formatted_from}</SVFROMDATE>
                        <SVTODATE TYPE="Date">{formatted_to}</SVTODATE>
                        {postdated_line}
                    </STATICVARIABLES>
                    <TDL>
                        <TDLMESSAGE>
                            <COLLECTION NAME="VoucherColl" ISINITIALISE="Yes">
                                <TYPE>Voucher</TYPE>
                                <FETCH>{fetch_fields}</FETCH>
                            </COLLECTION>
                        </TDLMESSAGE>
                    </TDL>
                </DESC>
            </BODY>
        </ENVELOPE>"""

        res = requests.post(self.tally_url, data=req_xml, headers={'Content-Type': 'text/xml'}, timeout=180)
        res.raise_for_status()
        clean_xml = sanitize_xml(res.content)
        root = ET.fromstring(clean_xml)
        return root.findall('.//VOUCHER')

    def _extract_bill_references(self, voucher) -> list:
        """
        Pulls bill-wise allocation references out of a voucher's ledger
        entries -- this is the piece that answers "which invoice does
        this receipt/CN settle against." Each BILLALLOCATIONS.LIST
        entry has a NAME (the bill/invoice reference) and a BILLTYPE
        ('New Ref', 'Agst Ref', 'Advance', 'On Account' -- 'Agst Ref'
        is specifically "settling against an existing bill", which is
        the case we care about here).
        """
        refs = []
        ledgers = (
            voucher.findall('.//ALLLEDGERENTRIES.LIST')
            + voucher.findall('.//LEDGERENTRIES.LIST')
        )
        for ledger in ledgers:
            bill_allocations = ledger.findall('.//BILLALLOCATIONS.LIST')
            for bill in bill_allocations:
                bill_name = bill.findtext('NAME', '').strip()
                bill_type = bill.findtext('BILLTYPE', '').strip()
                bill_amount = bill.findtext('AMOUNT', '0')
                if bill_name:
                    try:
                        amt = abs(float(bill_amount))
                    except ValueError:
                        amt = 0.0
                    refs.append({
                        'bill_reference': bill_name,
                        'bill_type': bill_type,
                        'bill_amount': amt,
                    })
        return refs

    def extract_receipts(self) -> pd.DataFrame:
        """
        Receipt vouchers within the financial-year window, one row per
        bill reference settled (a single receipt can settle multiple
        invoices, so this is at bill-allocation grain, not voucher
        grain -- mirrors how sales are at line-item grain, not invoice
        grain, for the same reason: consistent, joinable detail).
        """
        vouchers = self._fetch_vouchers_in_range(self.cutoff, self.today)
        rows = []
        for v in vouchers:
            vch_type = v.findtext('VOUCHERTYPENAME', '').strip().upper()
            if 'RECEIPT' not in vch_type:
                continue

            vch_no = v.findtext('VOUCHERNUMBER', '').strip()
            party = v.findtext('PARTYLEDGERNAME', '').strip()
            vch_date = v.findtext('DATE', '').strip()

            bill_refs = self._extract_bill_references(v)
            if not bill_refs:
                # A receipt with no bill allocation at all (e.g. "on
                # account", not yet matched to a specific invoice) --
                # still worth keeping as a row, just without a
                # resolvable invoice reference.
                rows.append({
                    'receipt_date': vch_date, 'voucher_number': vch_no,
                    'customer_name': party, 'bill_reference': None,
                    'bill_type': None, 'amount': None,
                    'division': identify_division(vch_no, party, vch_type),
                    'source_system': self.SOURCE_SYSTEM,
                })
            else:
                for ref in bill_refs:
                    rows.append({
                        'receipt_date': vch_date, 'voucher_number': vch_no,
                        'customer_name': party, 'bill_reference': ref['bill_reference'],
                        'bill_type': ref['bill_type'], 'amount': ref['bill_amount'],
                        'division': identify_division(vch_no, party, vch_type),
                        'source_system': self.SOURCE_SYSTEM,
                    })
        return pd.DataFrame(rows)

    def extract_credit_notes(self) -> pd.DataFrame:
        """
        Same shape and reasoning as extract_receipts, for Credit Note
        vouchers -- one row per bill reference the CN settles against.
        """
        vouchers = self._fetch_vouchers_in_range(self.cutoff, self.today)
        rows = []
        for v in vouchers:
            vch_type = v.findtext('VOUCHERTYPENAME', '').strip().upper()
            if 'CREDIT' not in vch_type and 'CN' not in vch_type:
                continue

            vch_no = v.findtext('VOUCHERNUMBER', '').strip()
            party = v.findtext('PARTYLEDGERNAME', '').strip()
            vch_date = v.findtext('DATE', '').strip()

            bill_refs = self._extract_bill_references(v)
            if not bill_refs:
                rows.append({
                    'cn_date': vch_date, 'voucher_number': vch_no,
                    'customer_name': party, 'bill_reference': None,
                    'bill_type': None, 'amount': None,
                    'division': identify_division(vch_no, party, vch_type),
                    'source_system': self.SOURCE_SYSTEM,
                })
            else:
                for ref in bill_refs:
                    rows.append({
                        'cn_date': vch_date, 'voucher_number': vch_no,
                        'customer_name': party, 'bill_reference': ref['bill_reference'],
                        'bill_type': ref['bill_type'], 'amount': ref['bill_amount'],
                        'division': identify_division(vch_no, party, vch_type),
                        'source_system': self.SOURCE_SYSTEM,
                    })
        return pd.DataFrame(rows)

    def extract_pdc(self) -> pd.DataFrame:
        """
        Post-dated cheques -- Receipt vouchers whose voucher date, or
        whose cheque/instrument date, is in the future, or which Tally
        itself explicitly flags as ISPOSTDATED. Reuses the exact
        detection logic already proven against this Tally install from
        earlier work in this project -- three independent signals, any
        one of which is enough to count a receipt as a PDC.

        Deliberately looks FORWARD, not backward, unlike every other
        extraction in this file: a PDC is only meaningful if its date
        is ahead of today, so the range runs from the same historical
        cutoff through the END of the current financial year, not up
        to today.
        """
        fy_start_year = self.today.year if self.today.month >= 4 else self.today.year - 1
        fy_end = datetime.date(fy_start_year + 1, 3, 31)

        vouchers = self._fetch_vouchers_in_range(self.cutoff, fy_end, include_postdated=True)
        today_str = self.today.strftime('%Y%m%d')

        rows = []
        for v in vouchers:
            vch_type = v.findtext('VOUCHERTYPENAME', '').strip().upper()
            if 'RECEIPT' not in vch_type:
                continue

            vch_no = v.findtext('VOUCHERNUMBER', '').strip()
            party = v.findtext('PARTYLEDGERNAME', '').strip()
            vch_date_raw = v.findtext('DATE', '').strip()
            is_postdated_flag = v.findtext('ISPOSTDATED', '').strip().upper() == 'YES'

            vch_date_str = format_tally_date(vch_date_raw) if vch_date_raw else ''
            is_future_vch_date = bool(vch_date_str and vch_date_str > today_str)

            # Scan every INSTRUMENTDATE in the voucher (root level and
            # nested inside BANKALLOCATIONS) for a future cheque date.
            is_future_inst_date = False
            found_inst_date = ''
            for inst in v.findall('.//INSTRUMENTDATE'):
                raw_inst = inst.text.strip() if inst is not None and inst.text else ''
                if raw_inst:
                    formatted_inst = format_tally_date(raw_inst)
                    if formatted_inst:
                        found_inst_date = formatted_inst
                        if formatted_inst > today_str:
                            is_future_inst_date = True
                            break

            # Any ONE of the three signals is enough -- not all three
            # required. A receipt might be flagged ISPOSTDATED by Tally
            # without a future voucher date, or vice versa.
            if not (is_future_vch_date or is_future_inst_date or is_postdated_flag):
                continue  # a normal, already-realized receipt -- not a PDC

            gross_amt = 0.0
            ledgers = v.findall('.//ALLLEDGERENTRIES.LIST') + v.findall('.//LEDGERENTRIES.LIST')
            for l in ledgers:
                try:
                    amt = abs(float(l.findtext('AMOUNT', '0')))
                    if amt > gross_amt:
                        gross_amt = amt
                except ValueError:
                    pass

            if gross_amt <= 0:
                continue

            reasons = []
            if is_future_vch_date:
                reasons.append('Future Vch Date')
            if is_future_inst_date:
                reasons.append('Future Chq Date')
            if is_postdated_flag:
                reasons.append('ISPOSTDATED Flag')

            rows.append({
                'voucher_number': vch_no,
                'voucher_date': vch_date_str,
                'cheque_date': found_inst_date or None,
                'customer_name': party,
                'amount': gross_amt,
                'reason': ', '.join(reasons),
                'division': identify_division(vch_no, party, vch_type),
                'source_system': self.SOURCE_SYSTEM,
            })

        return pd.DataFrame(rows)
    from config_loader import load_config

    config = load_config()
    adapter = TallyAdapter(
        tally_url="http://localhost:9000",
        financial_years_back=config["sync"]["financial_years_back"],
    )

    print("=== Outstanding ===")
    outstanding_df = adapter.extract_outstanding()
    print(outstanding_df.head())
    print(f"Total rows: {len(outstanding_df)}\n")

    print("=== Receipts (UNVALIDATED -- check this carefully) ===")
    receipts_df = adapter.extract_receipts()
    print(receipts_df.head(20))
    print(f"Total rows: {len(receipts_df)}\n")

    print("=== Credit Notes (UNVALIDATED -- check this carefully) ===")
    cn_df = adapter.extract_credit_notes()
    print(cn_df.head(20))
    print(f"Total rows: {len(cn_df)}\n")

    print("=== PDC (reuses proven detection logic, but new query shape -- verify) ===")
    pdc_df = adapter.extract_pdc()
    print(pdc_df.head(20))
    print(f"Total rows: {len(pdc_df)}")
